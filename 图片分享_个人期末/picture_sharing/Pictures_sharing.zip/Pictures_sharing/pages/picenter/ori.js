Page({
  data: {
    name: '',
    desc: '',
    cover: '',
    images: []
  },

  onShow: function () {
    const app = getApp();
    const albumData = app.globalData.albumData || {};
    const uploadData = app.globalData.uploadData || {};

    console.log('albumData:', albumData);
    console.log('uploadData:', uploadData);

    this.setData({
      name: albumData.name,
      desc: albumData.desc,
      cover: albumData.cover,
      images: app.globalData.images
    });

    if (uploadData.mediaUrl) {
      const newImage = {
        url: uploadData.mediaUrl,
        date: uploadData.date,
        desc: uploadData.desc
      };
      console.log('Adding new image:', newImage);
    const updatedImages = [...this.data.images, newImage];
    this.setData({
      images: updatedImages
    });
      app.globalData.images = [...app.globalData.images, newImage];

      // 清空上传数据，避免重复添加
      app.globalData.uploadData = {};
    }

    console.log('Final images data:', this.data.images);
    
    this.setData({
      images: app.globalData.images
    });
  },

  deleteImage: function (e) {
    const index = e.currentTarget.dataset.index;
    const app = getApp();
    app.globalData.images.splice(index, 1);
    this.setData({
      images: app.globalData.images
    });
  },

  goToUploadPage: function () {
    wx.switchTab({
      url: '/pages/upload/upload'
    });
  }
});
