Page({
  data: {
    name: '',
    desc: '',
    cover: '',
    images: []
  },

  onLoad: function () {
    const app = getApp();
    const albumData = app.globalData.albumData || {};
    this.setData({
      name: albumData.name,
      desc: albumData.desc,
      cover: albumData.cover,
      images: app.globalData.images || []
    });
  },

  onShow: function () {
    const app = getApp();
    const uploadData = app.globalData.uploadData || {};

    console.log('albumData:', this.data);
    console.log('uploadData:', uploadData);

    if (uploadData.mediaUrl) {
      const newImage = {
        url: uploadData.mediaUrl,
        date: uploadData.date,
        desc: uploadData.desc
      };

      const updatedImages = [...this.data.images, newImage];
      this.setData({
        images: updatedImages
      });

      app.globalData.images = updatedImages;
      app.globalData.uploadData = {};
    }

    console.log('Final images data:', this.data.images);
  },

  deleteImage: function (e) {
    const index = e.currentTarget.dataset.index;
    const app = getApp();
    const updatedImages = [...this.data.images];
    updatedImages.splice(index, 1);

    this.setData({
      images: updatedImages
    });

    app.globalData.images = updatedImages;
  },

  goToUploadPage: function () {
    wx.switchTab({
      url: '/pages/upload/upload'
    });
  }
});
