Page({
  data: {},
  navigateToHome() {
    wx.switchTab({
      url: '/pages/home/home'
    });
  }
});
