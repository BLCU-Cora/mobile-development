Page({
  data: {
    albumName: '',
    albumDesc: '',
    albumCover: ''
  },

  uploadImage: function () {
    wx.chooseImage({
      count: 1,
      success: (res) => {
        this.setData({
          albumCover: res.tempFilePaths[0]
        });
      }
    });
  },

  inputAlbumName: function (e) {
    this.setData({
      albumName: e.detail.value
    });
  },

  inputAlbumDesc: function (e) {
    this.setData({
      albumDesc: e.detail.value
    });
  },

  createAlbum: function () {
    const app = getApp();
    app.globalData.albumData = {
      name: this.data.albumName,
      desc: this.data.albumDesc,
      cover: this.data.albumCover
    };
    wx.switchTab({
      url: '/pages/picenter/picenter'
    });
  }
});
