Page({
  data: {
    name: '',
    desc: '',
    date: '点击选择日期',
    mediaUrl: ''
  },

  onLoad: function (options) {
    const app = getApp();
    this.setData({
      name: app.globalData.albumData.name
    });
  },

  inputDesc: function (e) {
    this.setData({
      desc: e.detail.value
    });
  },

  uploadMedia: function () {
    wx.showActionSheet({
      itemList: ['上传照片', '上传视频'],
      success: (res) => {
        if (res.tapIndex === 0) {
          wx.chooseImage({
            count: 1,
            success: (res) => {
              console.log('Chosen image path:', res.tempFilePaths[0]);
              this.setData({
                mediaUrl: res.tempFilePaths[0]
              });
            }
          });
        } else if (res.tapIndex === 1) {
          wx.chooseVideo({
            success: (res) => {
              console.log('Chosen video path:', res.tempFilePath);
              this.setData({
                mediaUrl: res.tempFilePath
              });
            }
          });
        }
      }
    });
  },

  bindDateChange: function (e) {
    this.setData({
      date: e.detail.value
    });
  },

  publish: function () {
    console.log('Publish button clicked');
    console.log('Navigating to picenter with data:', this.data);

    const app = getApp();
    app.globalData.uploadData = {
      name: this.data.name,
      desc: this.data.desc,
      date: this.data.date,
      mediaUrl: this.data.mediaUrl
    };

    wx.switchTab({
      url: '/pages/picenter/picenter',
      success: function () {
        console.log('SwitchTab successful');
      },
      fail: function (err) {
        console.error('SwitchTab failed', err);
      }
    });
  }
});
